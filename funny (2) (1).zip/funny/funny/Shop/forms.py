from django import forms
from Shop.models import Product


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = [
            'name',
            'type',
            'description',
            'price',
            'show'
        ]

